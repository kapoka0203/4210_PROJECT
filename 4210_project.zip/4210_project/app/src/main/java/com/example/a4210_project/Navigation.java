package com.example.a4210_project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;

import com.example.a4210_project.R;
import com.example.a4210_project.fragment.Chat_Fragment;
import com.example.a4210_project.fragment.Home_Fragment;
import com.example.a4210_project.fragment.Mission_Fragment;
import com.example.a4210_project.fragment.Upload_Fragment;
import com.example.a4210_project.fragment.User_Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Navigation extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {

    private Home_Fragment mHome_Fragment;
    private Mission_Fragment mMission_Fragment;
    private Upload_Fragment mUpload_Fragment;
    private Chat_Fragment mChat_Fragment;
    private User_Fragment mUser_Fragment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation);

        FragmentManager mFragment_Manager = getSupportFragmentManager();

        ((BottomNavigationView) findViewById(R.id.navigation)).setOnNavigationItemSelectedListener(this);
        ((BottomNavigationView) findViewById(R.id.navigation)).setSelectedItemId(R.id.navigation_home);

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        FragmentManager mFragment_Manager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = mFragment_Manager.beginTransaction();

        hide_Fragments(fragmentTransaction);

        switch (item.getItemId()) {
            case (R.id.navigation_home):

                if (mHome_Fragment == null) mHome_Fragment = new Home_Fragment();
                if (mMission_Fragment != null) fragmentTransaction.hide(mMission_Fragment);
                if (mUpload_Fragment != null) fragmentTransaction.hide(mUpload_Fragment);
                if (mChat_Fragment != null) fragmentTransaction.hide(mChat_Fragment);
                if (mUser_Fragment != null) fragmentTransaction.hide(mUser_Fragment);
                if (mHome_Fragment.isAdded()) {
                    fragmentTransaction.show(mHome_Fragment);
                } else {
                    fragmentTransaction.add(R.id.container_main, mHome_Fragment);
                }
                fragmentTransaction.commit();

                return true;
            case R.id.navigation_mission:

                if (mMission_Fragment == null) mMission_Fragment = new Mission_Fragment();
                if (mHome_Fragment != null) fragmentTransaction.hide(mHome_Fragment);
                if (mUpload_Fragment != null) fragmentTransaction.hide(mUpload_Fragment);
                if (mChat_Fragment != null) fragmentTransaction.hide(mChat_Fragment);
                if (mUser_Fragment != null) fragmentTransaction.hide(mUser_Fragment);
                if (mMission_Fragment.isAdded()) {
                    fragmentTransaction.show(mMission_Fragment);
                } else {
                    fragmentTransaction.add(R.id.container_main, mMission_Fragment);
                }
                fragmentTransaction.commit();
                return true;
            case R.id.navigation_upload:

                if (mUpload_Fragment == null) mUpload_Fragment = new Upload_Fragment();
                if (mMission_Fragment != null) fragmentTransaction.hide(mMission_Fragment);
                if (mHome_Fragment != null) fragmentTransaction.hide(mHome_Fragment);
                if (mChat_Fragment != null) fragmentTransaction.hide(mChat_Fragment);
                if (mUser_Fragment != null) fragmentTransaction.hide(mUser_Fragment);
                if (mUpload_Fragment.isAdded()) {
                    fragmentTransaction.show(mUpload_Fragment);
                } else {
                    fragmentTransaction.add(R.id.container_main, mUpload_Fragment);
                }
                fragmentTransaction.commit();

                return true;
            case R.id.navigation_chat:

                if (mChat_Fragment == null) mChat_Fragment = new Chat_Fragment();
                if (mMission_Fragment != null) fragmentTransaction.hide(mMission_Fragment);
                if (mHome_Fragment != null) fragmentTransaction.hide(mHome_Fragment);
                if (mUpload_Fragment != null) fragmentTransaction.hide(mUpload_Fragment);
                if (mUser_Fragment != null) fragmentTransaction.hide(mUser_Fragment);
                if (mChat_Fragment.isAdded()) {
                    fragmentTransaction.show(mChat_Fragment);
                } else {
                    fragmentTransaction.add(R.id.container_main, mChat_Fragment);
                }
                fragmentTransaction.commit();

                return true;
            case R.id.navigation_user:

                if (mUser_Fragment == null) mUser_Fragment = new User_Fragment();
                if (mMission_Fragment != null) fragmentTransaction.hide(mMission_Fragment);
                if (mHome_Fragment != null) fragmentTransaction.hide(mHome_Fragment);
                if (mUpload_Fragment != null) fragmentTransaction.hide(mUpload_Fragment);
                if (mChat_Fragment != null) fragmentTransaction.hide(mChat_Fragment);
                if (mUser_Fragment.isAdded()) {
                    fragmentTransaction.show(mUser_Fragment);
                } else {
                    fragmentTransaction.add(R.id.container_main, mUser_Fragment);
                }
                fragmentTransaction.commit();

                return true;
        }
        return false;
    }
    private void hide_Fragments(FragmentTransaction fragmentTransaction){
        if (mHome_Fragment != null){
            fragmentTransaction.hide(mHome_Fragment);
        }
        if (mMission_Fragment != null){
            fragmentTransaction.hide(mMission_Fragment);
        }
        if (mUpload_Fragment != null){
            fragmentTransaction.hide(mUpload_Fragment);
        }
        if (mChat_Fragment != null){
            fragmentTransaction.hide(mChat_Fragment);
        }
        if (mUser_Fragment != null){
            fragmentTransaction.hide(mUser_Fragment);
        }
    }
}